package com.swtjface.RCPExample;
import org.eclipse.ui.application.WorkbenchAdvisor;
import org.eclipse.swt.graphics.Point;
import org.eclipse.ui.application.IWorkbenchWindowConfigurer;

public class ExampleAdvisor extends WorkbenchAdvisor
{
  public String getInitialWindowPerspectiveId()
  {
    return "com.swtjface.RCPExample.ExamplePerspective";
  }
  
  public void preWindowOpen(IWorkbenchWindowConfigurer configurer)
  {
    super.preWindowOpen(configurer);
    configurer.setTitle("RCPExample");
    configurer.setInitialSize(new Point(225, 250));
    configurer.setShowMenuBar(false);
    configurer.setShowStatusLine(false);
    configurer.setShowCoolBar(false);
  }
}