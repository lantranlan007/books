package com.swtjface.RCPExample;
import org.eclipse.core.runtime.IPlatformRunnable;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.application.WorkbenchAdvisor;

public class ExampleApplication implements IPlatformRunnable
{
	
  public Object run(Object args) throws Exception
  {
    WorkbenchAdvisor advisor = new ExampleAdvisor();
    Display display = PlatformUI.createDisplay();
    int code = PlatformUI.createAndRunWorkbench(display, advisor);
    if (code == PlatformUI.RETURN_RESTART)
      return IPlatformRunnable.EXIT_RESTART;
    else
      return IPlatformRunnable.EXIT_OK;
  }
}
