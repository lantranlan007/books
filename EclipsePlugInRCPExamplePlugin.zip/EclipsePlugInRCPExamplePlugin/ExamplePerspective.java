package com.swtjface.RCPExample;
import org.eclipse.ui.*;

public class ExamplePerspective implements IPerspectiveFactory
{
  public void createInitialLayout(IPageLayout layout)
  {
    String editor = layout.getEditorArea();
    layout.addView("RCPExample.ExampleView",
    IPageLayout.RIGHT, 0f, editor);
    layout.setEditorAreaVisible(false);
    layout.setFixed(true);
  }
}
