package com.manning.javapersistence.ch06.model;

public class SwissZipcode extends Zipcode {

    public SwissZipcode(String value) {
        super(value);
    }
}
