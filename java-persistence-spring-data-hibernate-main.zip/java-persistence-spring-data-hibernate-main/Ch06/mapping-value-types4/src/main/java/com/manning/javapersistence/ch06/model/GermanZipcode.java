package com.manning.javapersistence.ch06.model;

public class GermanZipcode extends Zipcode {

    public GermanZipcode(String value) {
        super(value);
    }
}
