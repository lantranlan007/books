INSERT INTO ITEM (id, item_name, START_PRICE, description, verified, IMPERIALWEIGHT) VALUES (1, 'Some Item', 1, 'descriptiondescription', '1', 1000);
